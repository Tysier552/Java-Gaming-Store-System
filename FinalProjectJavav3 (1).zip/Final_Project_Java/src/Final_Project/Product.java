package Final_Project;

public class Product {
	private String name;
	private String category;
	private double price;
	private int quantity;
	public Product (String name, String category, double price, int quantity) {
		this .name = name;
		this .category = category;
		this .price = price;
		this .quantity = quantity;
	}
	// Getters and Setters
	public String getName () {
		return name;
	}
	public String getCategory () {
		return category;
	}
	public double getPrice () {
		return price;
	}
	public void updatePrice ( double newPrice) {
		this .price = newPrice;
	}
	public int getQuantity () {
		return quantity;
	}
	public void updateQuantity ( int newQuantity) {
		this .quantity = newQuantity;
	}
}
