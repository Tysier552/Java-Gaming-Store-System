package Final_Project;

public interface SupplierManagment {
	void addProduct (Product product);
	void updatePrice (Product product, double newPrice);
}
