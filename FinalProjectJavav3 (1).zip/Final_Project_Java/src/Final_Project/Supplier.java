package Final_Project;

import java.util.*;
import java.util.HashMap;
import java.util.Map;

public class Supplier implements SupplierManagment {

	private Map<String, Product> products;
	public Supplier () {
		this .products = new HashMap<>();
		addRandomProducts();
	}
	private void addRandomProducts() {
        String[] electronics = {"Laptop", "Smartphone", "Headphones", "Smartwatch"};
        String[] clothing = {"T-shirt", "Jeans", "Jacket", "Sneakers"};
        String[] books = {"The Great Gatsby", "1984", "To Kill a Mockingbird", "Moby Dick"};
        String[] home = {"Blender", "Microwave", "Vacuum Cleaner", "Coffee Maker"};
        String[] toys = {"Action Figure", "Doll", "Puzzle", "Board Game"};
        
        String[][] categories = {electronics, clothing, books, home,toys};
        String[] categoryNames = {"Electronics", "Clothing", "Books", "Home","Toys"};
        
        Random random = new Random();
        
        for (int i = 0; i < categories.length; i++) {
            String category = categoryNames[i];
            for (String productName : categories[i]) {
                double price = 10.0 + (100.0 - 10.0) * random.nextDouble();
                int quantity = 1 + random.nextInt(50);
                Product product = new Product(productName, category, price, quantity);
                addProduct(product);
            }
        }
    }
	@Override
	public void addProduct(Product product) {
        if (products.containsKey(product.getName())) {
            Product existingProduct = products.get(product.getName());
            existingProduct.updateQuantity(existingProduct.getQuantity() + product.getQuantity());
        } else {
            products.put(product.getName(), product);
        }
    }
	@Override
	public void updatePrice (Product product, double newPrice) {
		if (products.containsKey(product.getName())) {
            products.get(product.getName()).updatePrice(newPrice);
        }
	}
	public void updateQuantity(Product product, int newQuantity) {
        if (products.containsKey(product.getName())) {
            products.get(product.getName()).updateQuantity(newQuantity);
        }
	}
	public void displayInventory() {
        System.out.println("Manufacturer Inventory:");
        for (Product product : products.values()) {
            System.out.println(product.getName() + " - " + product.getQuantity());
        }
    }
	public Map<String, Product> getProducts() {
        return products;
    }
	
	public Product getProduct(String name) {
        return products.get(name);
    }
}
