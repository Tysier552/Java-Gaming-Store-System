package Final_Project;

//  Java Project (Inventory_X) a small shop 
// Project Participants: 
// Name: Tysier Zidan , I.D: 211611181 .
// Name: Kosay Gorban, I.D: 207796780 .
// Notes Before First Run of the program: 
// 0. please read the pdf file included to make it easier to you and for more understanding and clarification
// 1. There already is a Manager by the name of Tysier with the password Tysier123 
// 2. There already is a RegularEmployee by the name of Kusay with the password Kosay123
// 3. There already is a Customer named Gabi with the password Gabi123, but you also have the option to create a new Customer.
// 4. On the first run of the program there is an initialized store inventory (store stock) that can be accessed. In other words, you can access the Customer Section even from the first run.
// 5. The Supplier (ספק) is initialized using different products from different random categories.
// 6. in case this sign of writing (ins" | ") went to left, please move it to the right so there is no errors. 
// 7.for more clarification please look into the pdf file we uploaded with the project.

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StoreManagmentSystem.main(args);
	}

}
