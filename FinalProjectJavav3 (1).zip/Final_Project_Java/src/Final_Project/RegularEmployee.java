package Final_Project;
import java.util.*;
public class RegularEmployee extends Employee {

	public RegularEmployee(String name, String role, double salary, String password) {
		super(name, role, salary, password);
		// TODO Auto-generated constructor stub
	}
	public void processOrder(Inventory storeInventory, Order order) {
        try {
            order.processOrder(storeInventory);
            updateHours(1); // Update hours by 1 for every order processed (since each takes 30 minutes)
            System.out.println("Employee processed the order.");
        } catch (NullPointerException e) {
            System.out.println("Error: The order could not be processed because a required item was not found. " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while processing the order: " + e.getMessage());
        }
    }

	public void processPendingOrders(Inventory storeInventory, List<Order> pendingOrders) {
        try {
            if (pendingOrders == null || pendingOrders.isEmpty()) {
                System.out.println("No pending orders to process.");
                return;
            }
            for (Order order : pendingOrders) {
                processOrder(storeInventory, order);
            }
            pendingOrders.clear();
        } catch (NullPointerException e) {
            System.out.println("Error: The pending orders list is not initialized. " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred while processing pending orders: " + e.getMessage());
        }
    }

    @Override
    public void performDuties(Inventory storeInventory, List<Order> pendingOrders) {
        processPendingOrders(storeInventory, pendingOrders);
    }
}
