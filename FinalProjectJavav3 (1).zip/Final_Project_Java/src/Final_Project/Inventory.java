package Final_Project;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;



public class Inventory {
    private Map<String, Product> products;
    private double totalCost;
    	
    public Inventory() {
        this.products = new HashMap<>();
        this.totalCost=0.0;
        initializeStoreInventory();
    }
    private void initializeStoreInventory() {
    	 String[] electronics = {"Laptop", "Smartphone", "Headphones", "Smartwatch"};
         String[] clothing = {"T-shirt", "Jeans", "Jacket", "Sneakers"};
         String[] books = {"The Great Gatsby", "1984", "To Kill a Mockingbird", "Moby Dick"};
         String[] home = {"Blender", "Microwave", "Vacuum Cleaner", "Coffee Maker"};
         String[] toys = {"Action Figure", "Doll", "Puzzle", "Board Game"};

         String[][] categories = {electronics, clothing, books, home, toys};
         String[] categoryNames = {"Electronics", "Clothing", "Books", "Home", "Toys"};

         Random random = new Random();

         for (int i = 0; i < categories.length; i++) {
             String category = categoryNames[i];
             int numProducts = Math.min(3, categories[i].length); // Ensure no more than 3 products are added
             for (int j = 0; j < numProducts; j++) {
                 String productName = categories[i][j];
                 double price = 10.0 + (100.0 - 10.0) * random.nextDouble();
                 int quantity = 3;
                 Product product = new Product(productName, category, price, quantity);
                 addProduct(product);
             }
         }
		
	}
    public void addProduct(Product product) {
        if (products.containsKey(product.getName())) {
            Product existingProduct = products.get(product.getName());
            existingProduct.updateQuantity(existingProduct.getQuantity() + product.getQuantity());
        } else {
            products.put(product.getName(), product);
        }
    }

	public void updateStock(Product product, int amount) {
		if (products.containsKey(product.getName())) {
            products.get(product.getName()).updateQuantity(products.get(product.getName()).getQuantity() + amount);
        }
	}
	public void updatePrice(Product product, double newPrice) {
        if (products.containsKey(product.getName())) {
            products.get(product.getName()).updatePrice(newPrice);
        }
    }
	
	public void displayInventory() {
		System.out.println("Store Inventory: ");
		Map<String, Map<String, Product>> sortedProducts = new TreeMap<>();

        for (Product product : products.values()) {
            sortedProducts
                .computeIfAbsent(product.getCategory(), k -> new TreeMap<>())
                .put(product.getName(), product);
        }

       
        for (Map.Entry<String, Map<String, Product>> entry : sortedProducts.entrySet()) {
            System.out.println(entry.getKey() + ":");
            for (Product product : entry.getValue().values()) {
                System.out.println("  " + product.getName() + " - " + product.getQuantity() + " - $ " + product.getPrice());
            }
        }

	}
	public Product getProduct(String name) {
        return products.get(name);
    }
	
	public void updateTotalCost(double added) {
		this.totalCost+=added;
	}
	
	public double gettotalCost() {
		return totalCost;
	}
	
	public Map<String, Product> getProducts() {
		return products;
	}
}
