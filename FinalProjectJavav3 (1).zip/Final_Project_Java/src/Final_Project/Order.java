package Final_Project;

import java.util.ArrayList;
import java.util.List;

public class Order {
	private Customer customer;
    private List<Product> items;
    private double totalAmount;
    private String date;

    public Order(Customer customer) {
        this.customer = customer;
        this.items = new ArrayList<>();
        this.totalAmount = 0.0;
        this.date = java.time.LocalDate.now().toString();
    }
    public void addItem(Product product,int quantity) {
        for(int i=0;i<quantity;i++) {
        	this.items.add(product);
        }
        totalAmount += quantity* product.getPrice();
    }
    public void processOrder(Inventory storeInventory) {
       
        customer.addPurchase(this);
        System.out.println("Order processed from inventory successfully!");
    }
    // Getters
    public Customer getCustomer() {
        return customer;
    }
    public List<Product> getItems() {
        return items;
    }
    public double getTotalAmount() {
        return totalAmount;
    }
    public String getDate() {
        return date;
    }
}
