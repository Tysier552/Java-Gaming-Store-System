package Final_Project;
import java.util.*;
public abstract class Employee {
	private String name;
	private String role;
	private double salary;// salary in dollar (rate for hour).
	private double hoursWorked;
	private String password;
	
	public Employee (String name, String role, double salary ,String password) {
		this .name = name;
		this .role = role;
		this .salary = salary;
		this .hoursWorked = 0 ;
		this.password=password;
	}
	
	public boolean verifyPassword(String password) {
        return this.password.equals(password);
    }
	
	public void updateHours ( double hours) {
		this .hoursWorked += hours;
	}
	
	public double calculatePayroll () {
		return salary * hoursWorked;
	}
	
// Getters
	public String getName () {
		return name;
	}
	
	public String getRole () {
		return role;
	}
	
	public double getSalary () {
		return salary;
	}
	
	public double getHoursWorked () {
		return hoursWorked;
	}
	  public void viewHoursWorked() {
        System.out.println("Hours worked: " + getHoursWorked());
    }

    public void viewSalary() {
        System.out.println("Salary until now: " + calculatePayroll());
    }
	public abstract void performDuties(Inventory storeInventory,List<Order>pendingOrders);
}
