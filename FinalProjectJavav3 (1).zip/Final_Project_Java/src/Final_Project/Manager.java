package Final_Project;
import java.util.*;
import java.util.stream.Collectors;
public class Manager extends Employee {
	public Manager (String name, String role, double salary ,String password) {
		super (name, role, salary,password);
		}
	 public void addProductToInventory(Scanner scanner, Supplier supplier, Inventory storeInventory) {
	        Map<String, String> categories = supplier.getProducts().values().stream()
	                .collect(Collectors.toMap(Product::getName, Product::getCategory, (p1, p2) -> p1));

	        System.out.println("Available categories:");
	        categories.values().stream().distinct().forEach(System.out::println);

	        System.out.print("Enter the category you're looking for: ");
	        String category = scanner.nextLine();
	        if (!categories.containsValue(category)) {
	        	System.out.println("This category doesn't exist.");
	        	return;
	        }
	        System.out.println("Available products in category " + category + ":");
	        supplier.getProducts().values().stream()
	                .filter(product -> product.getCategory().equalsIgnoreCase(category))
	                .forEach(product -> System.out.println(product.getName() + " - " + product.getQuantity() + " in stock - $" + product.getPrice()));

	        System.out.print("Enter product name: ");
	        String name = scanner.nextLine();
	        Product supplierProduct = supplier.getProduct(name);
	        if (supplierProduct==null) {
	        	System.out.println("There is no product with such name");
	        	return;
	        }
	        if (supplierProduct != null && supplierProduct.getCategory().equalsIgnoreCase(category)) {
	            System.out.print("Enter quantity: ");
	            int quantity = scanner.nextInt();
	            scanner.nextLine(); // Consume newline
	            if (quantity<=0) {
	            	System.out.println("You have entered an invalid quantity");
	            	return;
	            }
	            if (supplierProduct.getQuantity() >= quantity) {
	                Product storeProduct = new Product(name, supplierProduct.getCategory(), supplierProduct.getPrice(), quantity);
	                storeInventory.addProduct(storeProduct);
	                supplier.updateQuantity(supplierProduct, supplierProduct.getQuantity() - quantity);
	                storeInventory.updateTotalCost(storeProduct.getQuantity()* storeProduct.getPrice());
	                System.out.println("Product added to store inventory successfully.");
	            } else {
	                System.out.println("Not enough stock in supplier inventory.");
	            }
	        } else {
	            System.out.println("Product not found in supplier inventory or category mismatch.");
	        }
	    }
	public void updateProductPriceInInventory(Scanner scanner, Inventory storeInventory) {
		storeInventory.displayInventory();
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        Product updatedProduct = storeInventory.getProduct(name);
        if (updatedProduct==null) {
        	System.out.println("There is no product with such name");
        	return;
        }
        System.out.print("Enter new price: ");
        double newPrice = scanner.nextDouble();
        scanner.nextLine();  // Consume newline
        if (newPrice<0) {
        	System.out.println("The price you entered is invalid");
        	return;
        }
        Product product = storeInventory.getProduct(name);
        if (product != null) {
            storeInventory.updatePrice(product, newPrice);
            System.out.println("Product price updated successfully.");
        } 
        else {
            System.out.println("Product not found in store inventory.");
        }
    }
	public void displayStoreInventoryCost(Inventory storeInventory) {
        System.out.println("Total cost of bought Products from Supplier: $" + storeInventory.gettotalCost());
    }
	@Override
	public void performDuties(Inventory storeInventory, List<Order> pendingOrders) {
		// TODO Auto-generated method stub
		// there is no duties to be performed for the manager
	}
}

