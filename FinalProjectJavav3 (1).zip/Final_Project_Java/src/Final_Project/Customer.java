package Final_Project;

import java.util.*;

public class Customer {
	private String name;
    private String address;
    private String phone;
    private List<Order> purchaseHistory;
    private String password;

    public Customer(String name, String address, String phone,String password) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.purchaseHistory = new ArrayList<>();
        this.password=password;
    }
    public boolean verifyPassword(String password) {
        return this.password.equals(password);
    }
    
    public void addPurchase(Order order) {
        purchaseHistory.add(order);
    }
    
    public void makeOrder(Scanner scanner, Inventory storeInventory) {
        
        storeInventory.displayInventory();

        System.out.print("Enter product name: ");
        String productName = scanner.nextLine();
        Product newProduct = storeInventory.getProduct(productName);
        if (newProduct==null) {
        	System.out.println("There is no product with such name");
        	return;
        }
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        Product product = storeInventory.getProducts().get(productName);
        if (product != null && product.getQuantity() >= quantity) {
            Order order = new Order(this);
            order.addItem(product, quantity);
            storeInventory.updateStock(product, -quantity);
            addPurchase(order);
            System.out.println("Order placed successfully. Total amount: " + order.getTotalAmount());
        } else {
            System.out.println("Product not available or insufficient quantity.");
        }
    }
    
    public void viewPurchaseHistory() {
        
        if(purchaseHistory.isEmpty()) {
        	System.out.println("Customer hasn't purchased anything yet.");
        	return;
        }
        System.out.println("Purchase History for " + name);
        for (Order order : purchaseHistory) {
            System.out.println("Order Date: " + order.getDate());
            System.out.println("Items:");
            for (Product product : order.getItems()) {
                System.out.println("- " + product.getName() + " ($" + product.getPrice() + ")");
            }
            System.out.println("Total Amount: $" + order.getTotalAmount());
            System.out.println();
        }
    }
    // Getters
    public String getName() {
        return name;
    }
    
    public String getPassword() {
    	return password;
    }
    
    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }
}
