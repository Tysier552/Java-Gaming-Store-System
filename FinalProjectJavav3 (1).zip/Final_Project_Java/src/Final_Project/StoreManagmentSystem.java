package Final_Project;
import java.util.*;

public class StoreManagmentSystem {
	private static Supplier supplier;
    private static Manager manager;
    private static Employee employee;
    private static List<Customer> customers;
    private static Customer currentCustomer;
    private static Inventory storeInventory;
    private static List<Order> pendingOrders;

    public static void main(String[] args) {
    	initializeSystem();
    	 Scanner scanner = new Scanner(System.in);
         while (true) {
        	 try {
                 System.out.println("Welcome to the InventoryX store, Please select your role: ");
                 System.out.println("1. Manager Section");
                 System.out.println("2. Employee Section");
                 System.out.println("3. Customer Section");
                 System.out.println("4. Exit");

                 int choice = scanner.nextInt();
                 scanner.nextLine();  // Consume newline

                 switch (choice) {
                     case 1:
                         handleManagerSection(scanner);
                         break;
                     case 2:
                         handleEmployeeSection(scanner);
                         break;
                     case 3:
                         handleCustomerSection(scanner);
                         break;
                     case 4:
                         System.out.println("Exiting the system. Goodbye!");
                         return;
                     default:
                         System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                 }
        	 } catch (InputMismatchException e) {
                 System.out.println("Invalid input. Please enter a number between 1 and 4.");
                 scanner.nextLine();  // Clear the invalid input
             } catch (Exception e) {
                 System.out.println("An unexpected error occurred: " + e.getMessage());
             }
         }
    }
    
    //here we edit the password and the personal info
    
    private static void initializeSystem() {
        supplier = new Supplier();
        manager = new Manager("Tysier", "Manager", 7000, "Tysier123");
        employee = new RegularEmployee("Kosay", "Employee", 35.0, "Kosay123");
        customers = new ArrayList<>();
        customers.add(new Customer("Gabi", "123 Street", "1234567890", "Gabi123"));
        storeInventory = new Inventory();
        pendingOrders = new ArrayList<>();
    }
    
    
    private static void viewPendingOrders() {
    	try {
            System.out.println("Pending Orders:");
            if (pendingOrders.isEmpty()) {
            	System.out.println("There is no pending orders yet.");
            	return;
            }
            for (Order order : pendingOrders) {
                System.out.println("Order for " + order.getCustomer().getName() + " - Total Amount: $" + order.getTotalAmount());
                System.out.println("Items:");
                for (Product product : order.getItems()) {
                    System.out.println("- " + product.getName() );
                }
            }
        } catch (NullPointerException e) {
            System.out.println("Error: No pending orders found. " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }
    
    private static void makeOrder(Scanner scanner) {
        
    	try {
            Order order = new Order(currentCustomer); // Create a new order for the current customer

            while (true) {
                
                storeInventory.displayInventory();

                System.out.print("Enter product name: ");
                String productName = scanner.nextLine();
                Product updatedProduct = storeInventory.getProduct(productName);
                if (updatedProduct==null) {
                	System.out.println("There is no product with such name");
                	return;
                }
                System.out.print("Enter quantity: ");
                int quantity = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                if (quantity<=0) {
                	System.out.println("Invalid input for quantity");
                	return;
                }
                Product product = storeInventory.getProduct(productName);
                if (product != null && product.getQuantity() >= quantity) {
                    order.addItem(product, quantity);
                    storeInventory.updateStock(product, -quantity);
                    System.out.println("Product added to order. Total amount so far: $" + order.getTotalAmount());
                } else {
                    System.out.println("Product not available or insufficient quantity.");
                }

                while (true) {
                    System.out.print("Do you want to continue buying products? (yes/no): ");
                    String continueBuying = scanner.nextLine();
                    if (continueBuying.equalsIgnoreCase("yes")) {
                        break;
                    } else if (continueBuying.equalsIgnoreCase("no")) {
                        if (order.getItems().size() > 0) {
                            currentCustomer.addPurchase(order);
                            pendingOrders.add(order);
                            System.out.println("Order placed successfully. Total amount: $" + order.getTotalAmount());
                        } else {
                            System.out.println("No items were added to the order.");
                        }
                        return;
                    } else {
                        System.out.println("Invalid input. Please enter 'yes' or 'no'.");
                    }
                }
            }
        } 
    	 
    	catch (NullPointerException e) {
            System.out.println("Error: The product was not found. " + e.getMessage());
        } 
    	catch (ArithmeticException e) {
            System.out.println("Arithmetic error: " + e.getMessage());
        } 
    	catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }
    
    private static void handleManagerSection(Scanner scanner) {
        System.out.print("Enter Manager Password: ");
        String password = scanner.nextLine();
        if (!manager.verifyPassword(password)) {
            System.out.println("Invalid password. Access denied.");
            return;
        }

        while (true) {
            try {
                System.out.println("Welcome to the Manager Section, Manager " +manager.getName());
                System.out.println("1. Add Product from Supplier to Store Inventory");
                System.out.println("2. Update Price in Store Inventory");
                System.out.println("3. View Cost of Products bought from Supplier");
                System.out.println("4. View Store Inventory Stock");
                System.out.println("5. Go Back");

                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (choice) {
                    case 1:
                        manager.addProductToInventory(scanner, supplier, storeInventory);
                        break;
                    case 2:
                        manager.updateProductPriceInInventory(scanner, storeInventory);
                        break;
                    case 3:
                        manager.displayStoreInventoryCost(storeInventory);
                        break;
                    case 4:
                    	storeInventory.displayInventory();
                    	break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 4.");
                scanner.nextLine();  // Clear the invalid input
            }
        }
    }
    private static void handleEmployeeSection(Scanner scanner) {
        System.out.print("Enter Employee Password: ");
        String password = scanner.nextLine();
        if (!employee.verifyPassword(password)) {
            System.out.println("Invalid password. Access denied.");
            return;
        }

        while (true) {
            try {
                System.out.println("Welcome to the Employee Section "+employee.getName());
                System.out.println("1. See Hours Worked");
                System.out.println("2. See Salary");
                System.out.println("3. Process Orders");
                System.out.println("4. View Pending Orders");
                System.out.println("5. Go Back");

                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (choice) {
                    case 1:
                    	
                        employee.viewHoursWorked();
                        System.out.println("");
                        break;
                    case 2:
                    	System.out.println("");
                        employee.viewSalary();
                        System.out.println("");
                        break;
                    case 3:
                    	System.out.println("");
                        employee.performDuties(storeInventory, pendingOrders);
                        System.out.println("");
                        break;
                    case 4:
                    	System.out.println("");
                        viewPendingOrders();
                        System.out.println("");
                        break;
                    case 5:
                        return;
                    default:
                    	System.out.println("");
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                        System.out.println("");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number between 1 and 5.");
                scanner.nextLine();  // Clear the invalid input
            }
        }
    }
    private static void handleCustomerSection(Scanner scanner) {
    	try {
            System.out.println("Are you a new customer or a regular?");
            System.out.println("1. New customer");
            System.out.println("2. Regular customer");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    CreateCustomer(scanner);
                    break;
                case 2:
                    handleRegularCustomer(scanner);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter 1 or 2.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter 1 or 2.");
            scanner.nextLine();  // Clear the invalid input
        }
    }
    	
    private static void CreateCustomer(Scanner scanner) {
    	 try {
             String name;
             boolean nameExists;
             do {
            	 nameExists=false;
            	 System.out.print("Enter your name: ");
                  name = scanner.nextLine();
                 for (Customer cust: customers) {
                	 if (cust.getName().equals(name)) {
                		 nameExists=true;
                		 System.out.println("There is already a customer with this name");
                		 break;
                	 }
                 }
            	 
             }while (nameExists);
             System.out.print("Enter your address: ");
             String address = scanner.nextLine();
             System.out.print("Enter your phone number: ");
             String phoneNumber = scanner.nextLine();
             String password;
             boolean passwordExists;
             do {
                 System.out.print("Create a password: "); // if the new customer tries a password that is already taken by another customer he will be asked to change it.
                 password = scanner.nextLine();

                 passwordExists = false;
                 for (Customer cust : customers) {
                     if (cust.verifyPassword(password)) {
                         passwordExists = true;
                         System.out.println("This password is already in use. Please choose a different password.");
                         break;
                     }
                 }
             } while (passwordExists);
             
             Customer newCustomer = new Customer(name, address, phoneNumber, password);
             customers.add(newCustomer);
             currentCustomer = newCustomer; // Set the current customer
             System.out.println("Customer account created successfully!");
             handleRegularCustomer(scanner);
         } catch (Exception e) {
             System.out.println("An unexpected error occurred while creating a new customer: " + e.getMessage());
         }
    }
    private static void handleRegularCustomer(Scanner scanner) {
    	try {
            System.out.print("Enter Customer Password: ");
            String password = scanner.nextLine();
            Customer foundCustomer = null;
            for (Customer cust : customers) {
                if (cust.verifyPassword(password)) {
                    foundCustomer = cust;
                    break;
                }
            }
       
            if (foundCustomer == null) {
                System.out.println("Invalid password. Access denied.");
                System.out.println("If you forgot your password type  yes ");//so we can help you get it back
                System.out.println("If NOT type anything else, to return");
                String choice=scanner.nextLine();
                

                
                if (choice.equalsIgnoreCase("yes")) {
                	System.out.println("Please enter your name so we can locate your account");
                	String name=scanner.nextLine();
                	for (Customer cust: customers) {
                		if (cust.getName().equals(name)) {
                			System.out.println("We have found your account and your password is: " +cust.getPassword());
                			return;
                		}
                	}
                }
                
         
               
                else return;
            }
            
            
            currentCustomer = foundCustomer; // Set the current customer
            while (true) {
                try {
                    System.out.println("Welcome to the Customer Section "+currentCustomer.getName());
                    System.out.println("1. Make an Order");
                    System.out.println("2. View Purchase History");
                    System.out.println("3. View All Store Products");
                    System.out.println("4. Go Back");

                    int choice = scanner.nextInt();
                    scanner.nextLine();  // Consume newline

                    switch (choice) {
                        case 1:
                            makeOrder(scanner);
                            break;
                        case 2:
                            currentCustomer.viewPurchaseHistory();
                            break;
                        case 3:
                        	storeInventory.displayInventory();
                        	break;
                        case 4:
                            return;
                        default:
                            System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a number between 1 and 3.");
                    scanner.nextLine();  // Clear the invalid input
                }
            }
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }
}
